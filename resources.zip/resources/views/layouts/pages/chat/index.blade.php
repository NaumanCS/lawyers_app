@extends('layouts.mainlayout')
@section('content')
    <livewire:admin-chat />
@endsection