<template>
    <div>Hello vue 3</div>
</template>


<script>
export default {
  name: 'Chat', // Make sure the component name is 'chat'
};
</script>
